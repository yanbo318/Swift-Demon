//
//  SecondViewController.swift
//  FireBaseDemo
//
//  Created by Antonio Chen on 2019/4/26.
//  Copyright © 2019 Antonio Chen. All rights reserved.
//

import UIKit
//import Firebase
//import FirebasePerformance

import Crashlytics


class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        let trace = Performance.startTrace(name: "test trace")
//        trace!.incrementMetric("retry", by: 1)
//        trace!.stop()
        // Do any additional setup after loading the view.
         //系统
//        Analytics.logEvent(AnalyticsEventSelectContent, parameters: [
////            AnalyticsParameterItemID: "NextViewController:id- 005",
////            AnalyticsParameterItemName: "005",
//            AnalyticsParameterContentType: "cont",
//            AnalyticsParameterTravelClass: classForCoder.description(),
//            AnalyticsParameterMethod: #function
//            ])
        let abc: String?
        var string:String? = "ac"
        abc = nil
//        print(abc!)
        //直接添加事件
//        Analytics.logEvent("share_image", parameters: [
//            "name": "name" as NSObject,
//            "full_text": "text" as NSObject
//            ])
        //系统
//        Analytics.setScreenName("TscreenName: String", screenClass: "screenClass: SecondViewController")
    }
    
    func crashMethod()  {
        Crashlytics.sharedInstance().crash()
        

    }
    @IBAction func crashClick(_ sender: UIButton) {
        crashMethod()
    }
    

}
