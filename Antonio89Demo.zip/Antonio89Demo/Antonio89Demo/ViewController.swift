//
//  ViewController.swift
//  Antonio89Demo
//
//  Created by Antonio Chen on 2019/4/29.
//  Copyright © 2019 Antonio Chen. All rights reserved.
//

import UIKit
import FirebasePerformance
import Firebase

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        Analytics.setScreenName(classForCoder.description(), screenClass: self.classForCoder.description())
//        
//        Analytics.logEvent(AnalyticsEventSelectContent, parameters: [
//                        AnalyticsParameterItemID: "NextViewController:id- 005",
//                        AnalyticsParameterItemName: "005",
//                        AnalyticsParameterContentType: "cont",
//            AnalyticsParameterTravelClass: classForCoder.description(),
//            AnalyticsParameterMethod: #function
//            ])
        
        print(classForCoder.description())
        //       var tracea = Performance.startTrace(name: "test trace")
        //        tracea!.incrementMetric("retrys", by: 1)
        
        let btn = UIButton.init(type: UIButton.ButtonType.system)
        btn.frame = CGRect.init(x: 50, y: self.view.frame.size.height - 100, width: 100, height: 100)
        btn.addTarget(self, action: #selector(click), for: UIControl.Event.touchUpInside)
        btn.backgroundColor = UIColor.lightGray
        btn.titleLabel?.text = "Stop"
        self.view.addSubview(btn)
        
        //        let btn2 = UIButton.init(type: UIButton.ButtonType.system)
        //        btn2.frame = CGRect.init(x: 250, y: 100, width: 100, height: 100)
        //        btn2.addTarget(self, action: #selector(click2), for: UIControl.Event.touchUpInside)
        //        btn2.backgroundColor =  UIColor.init(red: 202.0/255.0, green: 242.0/255.0, blue: 124.0/255.0, alpha: 1)
        //        btn.titleLabel?.text = "Screen"
        //        self.view.addSubview(btn2)
        
        
    }
    
    @IBAction func clickAction(_ sender: UIButton) {
        //        var tracea = Performance.startTrace(name: "test1 trace1")
        //
        //        // Update scenario.
        //        tracea!.setValue("B", forAttribute: "experiment")
        //
        //        // Reading scenario.
        //        let experimentValue:String? = tracea?.value(forAttribute: "experiment")
        //        print(experimentValue)
        // Delete scenario.
        //        tracea!.removeAttribute("experiment")
        
        
//        Analytics.logEvent(AnalyticsEventLogin, parameters: nil)
//        
//        Analytics.logEvent(AnalyticsEventSelectContent, parameters: [
//            AnalyticsParameterItemID: "stopBtn:id- 003",
//            AnalyticsParameterItemName: "title",
//            AnalyticsParameterContentType: "cont"
//            ])
    }
    @objc func click() {
        //        tracea?.stop()
        Analytics.logEvent(AnalyticsEventSelectContent, parameters: [
            AnalyticsParameterItemID: "stopBtn:id- 003",
            AnalyticsParameterItemName: "title",
            AnalyticsParameterContentType: "cont"
            ])
        
    }
    
    @IBAction func clickActionScreen(_ sender: UIButton) {
        Analytics.logEvent(AnalyticsEventSelectContent, parameters: [
            AnalyticsParameterItemName: "003",
            AnalyticsParameterTravelClass: classForCoder.description(),
            AnalyticsParameterMethod: #function
            ])
        
        let trace = Performance.startTrace(name: "test trace")
        trace!.incrementMetric("retry", by: 1)
    }
    
    
}

